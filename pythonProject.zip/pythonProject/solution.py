import pandas as pd
from textblob import TextBlob
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LinearRegression
import os

# 1. 加载数据
df = pd.read_csv('test(in).csv')
df['date'] = pd.to_datetime(df['date'])
df = df.sort_values('date')

# 2. 情感分析逻辑
def get_sentiment(text):
    if not isinstance(text, str): return 0.0, 'Neutral'
    blob = TextBlob(text)
    polarity = blob.sentiment.polarity
    label = 'Positive' if polarity > 0.05 else ('Negative' if polarity < -0.05 else 'Neutral')
    return polarity, label

results = df['body'].apply(get_sentiment)
df['polarity'] = [r[0] for r in results]
df['sentiment'] = [r[1] for r in results]

# 3. 月度评分与回归趋势
monthly_sentiment = df.set_index('date')['polarity'].resample('ME').mean().reset_index().dropna()
monthly_sentiment['date_ordinal'] = monthly_sentiment['date'].map(pd.Timestamp.toordinal)
X, y = monthly_sentiment[['date_ordinal']].values, monthly_sentiment['polarity'].values
model = LinearRegression().fit(X, y)
monthly_sentiment['trend'] = model.predict(X)

# 4. 排名与风险识别 (前20%活跃用户中评分最低的)
ranking = df.groupby('from').agg(count=('body', 'count'), avg_pol=('polarity', 'mean'))
risk = ranking[ranking['count'] >= ranking['count'].quantile(0.8)].sort_values('avg_pol').head(10)

# 5. 生成可视化图表
plt.figure(figsize=(10,6))
sns.countplot(x='sentiment', data=df, palette='viridis', order=['Positive', 'Neutral', 'Negative'])
plt.title('Sentiment Distribution')
plt.savefig('sentiment_distribution.png')

# 6. 保存所有要求的文件
df.to_csv('processed_sentiment_data.csv', index=False)
monthly_sentiment.to_csv('monthly_sentiment_scoring.csv', index=False)
ranking.to_csv('employee_ranking.csv')
risk.to_csv('flight_risk_identification.csv')

# 7. 生成 README
with open('README.md', 'w') as f:
    f.write("# LLM Assessment Solution\n\nMethodology: Used TextBlob for sentiment tagging and Linear Regression for trend analysis.")

print("所有文件已生成！请查看当前文件夹。")