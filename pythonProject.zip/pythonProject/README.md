# LLM Assessment Solution

Methodology: Used TextBlob for sentiment tagging and Linear Regression for trend analysis.